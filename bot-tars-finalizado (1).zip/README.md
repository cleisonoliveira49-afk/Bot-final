# Bot TARS 🤖

Bot de Telegram com comandos personalizados para moto entregador.

## Como rodar no Render

1. Crie um novo Web Service no [Render.com](https://render.com/)
2. Conecte com este repositório ou envie manualmente os arquivos
3. Configure:
   - **Build command:** `pip install -r requirements.txt`
   - **Start command:** `python main.py`
   - **Environment variable:** `BOT_TOKEN` com o valor do token do BotFather
